GEMINI_KEY = [
    # quangnm
    "AIzaSyD2eQb1SJqad20y7vHcke_QuA2Yuz-NhoM",
    "AIzaSyBFWWNAU8g7w-ktopCRucQcU3QFHKKGT88",
    "AIzaSyDkwgNlAcPdQVP8SguociqitvKs6TJiIic",
    "AIzaSyDLpXwQYKRfN1dPeuLVlQi_0GeZB8YLQ6M",
    "AIzaSyDN66U7hVa9o_Rdq8wysNdP9WkP71_KAG8",
    # luyennd
    "AIzaSyB6OBSAoTR7TCGzGsNqIBzHp7FrIW5R-2Q",   # bk
    "AIzaSyDoc8Tq25ZkUYWl9XeyuLb7t1jyqp-nG3Y",   # nht
    "AIzaSyAnfYceSbVi4Nj9SY_Xt6fEonRWwkwl4so",   # tomosia
    "AIzaSyCOyorzZ8vm92BiuZY7Z2Hbt34i2D_Adkk",   # csp
    "AIzaSyCa8KFLqX99kqT8HkjGijAAuRRcJQJxKzI",   # ntt
    "AIzaSyC8rLSw15QLuWntg5T02mbIzJS19fk-5zc",   # ngo hoang ton 
]