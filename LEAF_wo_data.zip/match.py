import copy

IDS_ROOT = 'data/data_ids'
ORIGINAL_ROOT = 'original_data'
DATASET = 'MAVEN'

def match(ids_dict:dict, original_dict:dict) -> dict:
    """
    Match the ids in ids_dict with the original_dict and return a new dictionary with the matched ids.
    """
    for key, value in ids_dict.items():
        if key not in original_dict:
            print(f"Key {key} not found in original data")
            continue
        ids_dict[key]['text'] = original_dict[key]['text'].lower().strip()
        ids_dict[key]['tokens'] = ids_dict[key]['text'].split()
    